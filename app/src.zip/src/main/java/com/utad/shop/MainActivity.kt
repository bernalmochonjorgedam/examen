package com.utad.shop

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MainActivity : Application()