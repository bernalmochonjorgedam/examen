package com.utad.shop.ui.electronics

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.utad.films.R
import com.utad.shop.data.local.entities.ElectronicEntity

class ElectronicAdapter {


}